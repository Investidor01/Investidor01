
import React, { useEffect, useState, useRef } from "react";
import {
  FaMoon,
  FaSun,
  FaShareAlt,
  FaExternalLinkAlt,
  FaUserCircle,
} from "react-icons/fa";
import { format } from "date-fns";
import ptBR from "date-fns/locale/pt-BR";
import "./index.css";

const NEWS_API_KEY = process.env.REACT_APP_NEWS_API_KEY;
const OPENWEATHER_KEY = process.env.REACT_APP_WEATHER_API_KEY;

const MOCK_USER = {
  username: "admin",
  password: "123456",
  name: "Administrador Dantas",
};

const CITIES = [
  { name: "São Paulo", lat: -23.55052, lon: -46.633308 },
  { name: "Rio de Janeiro", lat: -22.906847, lon: -43.172896 },
  { name: "Brasília", lat: -15.794229, lon: -47.882166 },
  { name: "Belo Horizonte", lat: -19.916681, lon: -43.934493 },
];

async function fetchNews(category = "") {
  const base = "https://newsapi.org/v2/top-headlines?language=pt&country=br";
  const url = category ? \`\${base}&category=\${category}\` : base;
  const res = await fetch(\`\${url}&apiKey=\${NEWS_API_KEY}\`);
  const data = await res.json();
  return data.articles || [];
}

async function fetchWeather(cities) {
  const list = await Promise.all(
    cities.map(async (city) => {
      const res = await fetch(
        \`https://api.openweathermap.org/data/2.5/weather?lat=\${city.lat}&lon=\${city.lon}&units=metric&lang=pt&appid=\${OPENWEATHER_KEY}\`
      );
      const data = await res.json();
      return { ...city, weather: data };
    })
  );
  return list;
}

function requestNotificationPermission() {
  if (Notification.permission === "default") Notification.requestPermission();
}

function sendNotification({ title, body, url }) {
  if (Notification.permission === "granted") {
    const n = new Notification(title, { body, tag: url });
    n.onclick = () => window.open(url, "_blank");
  }
}

function Logo() {
  return (
    <svg className="w-10 h-10 mr-3" viewBox="0 0 64 64" fill="none">
      <circle cx="32" cy="32" r="30" fill="#FF6B00" />
      <text x="50%" y="55%" textAnchor="middle" fontSize="28" fontWeight="bold" fill="white" fontFamily="Arial, sans-serif">IDB</text>
    </svg>
  );
}

function ShareButton({ url, title }) {
  const share = () => {
    if (navigator.share) navigator.share({ title, url });
    else navigator.clipboard.writeText(url);
  };
  return (
    <button className="flex items-center space-x-1 bg-blue-600 text-white px-3 py-1 rounded hover:bg-blue-700" onClick={share}>
      <FaShareAlt /> <span>Compartilhar</span>
    </button>
  );
}

export default function App() {
  const [user, setUser] = useState(null);
  const [u, setU] = useState("");
  const [p, setP] = useState("");
  const [err, setErr] = useState("");

  const [theme, setTheme] = useState("light");
  const [now, setNow] = useState(new Date());
  const [news, setNews] = useState({});
  const [weather, setWeather] = useState([]);
  const urls = useRef(new Set());

  useEffect(() => {
    const s = localStorage.getItem("theme") || "light";
    setTheme(s);
    document.documentElement.classList.toggle("dark", s === "dark");
    const su = localStorage.getItem("user");
    if (su) setUser(JSON.parse(su));
  }, []);

  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    if (!user) return;
    (async () => {
      const cats = ["general", "business", "technology", "sports", "health", "science", "entertainment"];
      let obj = {};
      for (let c of cats) obj[c] = await fetchNews(c);
      const inv = await fetchNews("business");
      obj["investimento"] = inv.filter((a) => /investimento|bolsa|criptomoeda|bitcoin/i.test(a.title));
      setNews(obj);
    })();
    fetchWeather(CITIES).then(setWeather);
    requestNotificationPermission();
    const iid = setInterval(async () => {
      const b = await fetchNews();
      b.filter((a) => /urgente|breaking news|alerta|emergência/i.test(a.title)).forEach((a) => {
        if (!urls.current.has(a.url)) {
          sendNotification({
            title: "Breaking: " + a.title,
            body: a.description || "",
            url: a.url,
          });
          urls.current.add(a.url);
        }
      });
    }, 10 * 60 * 1000);
    return () => clearInterval(iid);
  }, [user]);

  const login = (e) => {
    e.preventDefault();
    if (u === "admin" && p === "123456") {
      const x = { name: "Admin Dantas" };
      setUser(x);
      localStorage.setItem("user", JSON.stringify(x));
      setErr("");
    } else setErr("Credenciais inválidas.");
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem("user");
  };

  const toggle = () => {
    const n = theme === "light" ? "dark" : "light";
    setTheme(n);
    localStorage.setItem("theme", n);
    document.documentElement.classList.toggle("dark", n === "dark");
  };

  const RNS = (ti, arr) =>
    arr && arr.length ? (
      <section className="my-8">
        <h2 className="text-2xl font-semibold mb-2">{ti}</h2>
        <div className="grid md:grid-cols-3 gap-4">
          {arr.slice(0, 6).map((a, i) => (
            <div key={i} className="bg-white dark:bg-gray-800 rounded shadow p-4 flex flex-col">
              {a.urlToImage && <img src={a.urlToImage} alt="" className="w-full h-32 object-cover rounded mb-2" />}
              <h3 className="font-semibold">{a.title}</h3>
              <a href={a.url} target="_blank" rel="noopener noreferrer" className="text-blue-600 dark:text-blue-300 font-semibold mt-auto">
                Ler mais <FaExternalLinkAlt />
              </a>
              <ShareButton url={a.url} title={a.title} />
            </div>
          ))}
        </div>
      </section>
    ) : null;

  return (
    <div className={\`min-h-screen \${theme === "dark" ? "bg-gray-900 text-white" : "bg-gray-100 text-black"}\`}>
      <nav className="fixed top-0 w-full bg-blue-900 dark:bg-gray-900 p-3 flex justify-between items-center z-10">
        <div className="flex items-center">
          <Logo />
          <span className="text-xl font-bold text-white">INFO DANTAS BRASIL</span>
        </div>
        <div className="flex items-center space-x-3">
          <button onClick={toggle}>{theme === "light" ? <FaMoon /> : <FaSun />}</button>
          {user ? (
            <>
              <div className="flex items-center space-x-2"><FaUserCircle /><span>{user.name}</span></div>
              <button onClick={logout} className="bg-red-600 px-2 py-1 rounded">Sair</button>
            </>
          ) : (
            <form onSubmit={login} className="flex space-x-2">
              <input type="text" placeholder="Usuário" className="px-2 py-1 rounded text-black" value={u} onChange={e => setU(e.target.value)} />
              <input type="password" placeholder="Senha" className="px-2 py-1 rounded text-black" value={p} onChange={e => setP(e.target.value)} />
              <button type="submit" className="bg-green-600 px-2 py-1 rounded">Entrar</button>
            </form>
          )}
        </div>
      </nav>
      <main className="pt-20 px-4 pb-10 max-w-4xl mx-auto">
        {err && <p className="text-red-500">{err}</p>}
        <p className="text-sm font-mono">{format(now, "EEEE, dd 'de' MMMM yyyy, HH:mm:ss", { locale: ptBR })}</p>
        <div className="my-4">
          {weather.map((w, i) =>
            w.weather && w.weather.cod === 200 && (
              <div key={i} className="bg-white dark:bg-gray-800 rounded shadow p-4 flex items-center space-x-4">
                <img src={\`https://openweathermap.org/img/wn/\${w.weather.weather[0].icon}.png\`} />
                <div>
                  <div className="font-semibold">{w.name}</div>
                  <div>{Math.round(w.weather.main.temp)}°C - {w.weather.weather[0].description}</div>
                </div>
              </div>
            )
          )}
        </div>
        {user && (
          <>
            {RNS("Geral", news.general)}
            {RNS("Negócios", news.business)}
            {RNS("Tecnologia", news.technology)}
            {RNS("Esportes", news.sports)}
            {RNS("Saúde", news.health)}
            {RNS("Ciência", news.science)}
            {RNS("Entretenimento", news.entertainment)}
            {RNS("Investimentos", news.investimento)}
          </>
        )}
      </main>
    </div>
  );
}
