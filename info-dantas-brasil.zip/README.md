# Info Dantas Brasil

Projeto React com notícias e clima em tempo real.

```bash
npm install
npm start
```

Coloque suas chaves em `.env`:
```
REACT_APP_NEWS_API_KEY=...
REACT_APP_WEATHER_API_KEY=...
```